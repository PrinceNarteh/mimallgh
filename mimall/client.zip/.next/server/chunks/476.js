"use strict";
exports.id = 476;
exports.ids = [476];
exports.modules = {

/***/ 2476:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ authOptions),
/* harmony export */   "W": () => (/* binding */ getServerAuthSession)
/* harmony export */ });
/* harmony import */ var _next_auth_prisma_adapter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2104);
/* harmony import */ var _next_auth_prisma_adapter__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_next_auth_prisma_adapter__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7449);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7837);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_4__]);
_db__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





/**
 * Options for NextAuth.js used to configure
 * adapters, providers, callbacks, etc.
 * @see https://next-auth.js.org/configuration/options
 **/ const authOptions = {
    callbacks: {
        session ({ session , user  }) {
            if (session.user) {
                session.user.id = user.id;
                session.user.role = user.role;
            }
            return session;
        }
    },
    pages: {
        signIn: "/auth/login"
    },
    adapter: (0,_next_auth_prisma_adapter__WEBPACK_IMPORTED_MODULE_0__.PrismaAdapter)(_db__WEBPACK_IMPORTED_MODULE_4__/* .prisma */ ._),
    providers: [
        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_3___default()({
            name: "credentials",
            credentials: {
                email: {
                    type: "email"
                },
                password: {
                    type: "password"
                }
            },
            async authorize (credentials) {
                const { email , password  } = credentials;
                const user = await _db__WEBPACK_IMPORTED_MODULE_4__/* .prisma.user.findUnique */ ._.user.findUnique({
                    where: {
                        email
                    }
                });
                if (user && await bcryptjs__WEBPACK_IMPORTED_MODULE_1___default().compare(password, user.password)) {
                    return user;
                }
                return null;
            }
        })
    ]
};
/**
 * Wrapper for getServerSession so that you don't need
 * to import the authOptions in every file.
 * @see https://next-auth.js.org/configuration/nextjs
 **/ const getServerAuthSession = (ctx)=>{
    return (0,next_auth__WEBPACK_IMPORTED_MODULE_2__.getServerSession)(ctx.req, ctx.res, authOptions);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7837:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ prisma)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5694);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_env_server_mjs__WEBPACK_IMPORTED_MODULE_1__]);
_env_server_mjs__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const globalForPrisma = globalThis;
const prisma = globalForPrisma.prisma || new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    log: _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env.NODE_ENV */ .O.NODE_ENV === "development" ? [
        "query",
        "error",
        "warn"
    ] : [
        "error"
    ]
});
if (false) {}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5830:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ env),
/* harmony export */   "o": () => (/* binding */ formatErrors)
/* harmony export */ });
/* harmony import */ var _schema_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5596);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_schema_mjs__WEBPACK_IMPORTED_MODULE_0__]);
_schema_mjs__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-check

const _clientEnv = _schema_mjs__WEBPACK_IMPORTED_MODULE_0__/* .clientSchema.safeParse */ .Xq.safeParse(_schema_mjs__WEBPACK_IMPORTED_MODULE_0__/* .clientEnv */ .xZ);
const formatErrors = (/** @type {import('zod').ZodFormattedError<Map<string,string>,string>} */ errors)=>Object.entries(errors).map(([name, value])=>{
        if (value && "_errors" in value) return `${name}: ${value._errors.join(", ")}\n`;
    }).filter(Boolean);
if (!_clientEnv.success) {
    console.error("❌ Invalid environment variables:\n", ...formatErrors(_clientEnv.error.format()));
    throw new Error("Invalid environment variables");
}
for (let key of Object.keys(_clientEnv.data)){
    if (!key.startsWith("NEXT_PUBLIC_")) {
        console.warn(`❌ Invalid public environment variable name: ${key}. It must begin with 'NEXT_PUBLIC_'`);
        throw new Error("Invalid public environment variable name");
    }
}
const env = _clientEnv.data;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5596:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nb": () => (/* binding */ serverEnv),
/* harmony export */   "Rz": () => (/* binding */ serverSchema),
/* harmony export */   "Xq": () => (/* binding */ clientSchema),
/* harmony export */   "xZ": () => (/* binding */ clientEnv)
/* harmony export */ });
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([zod__WEBPACK_IMPORTED_MODULE_0__]);
zod__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-check

/**
 * Specify your server-side environment variables schema here.
 * This way you can ensure the app isn't built with invalid env vars.
 */ const serverSchema = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    DATABASE_URL: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().url(),
    NODE_ENV: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "development",
        "test",
        "production"
    ]),
    NEXTAUTH_SECRET:  true ? zod__WEBPACK_IMPORTED_MODULE_0__.z.string().min(1) : 0,
    NEXTAUTH_URL: zod__WEBPACK_IMPORTED_MODULE_0__.z.preprocess(// This makes Vercel deployments not fail if you don't set NEXTAUTH_URL
    // Since NextAuth.js automatically uses the VERCEL_URL if present.
    (str)=>process.env.VERCEL_URL ?? str, // VERCEL_URL doesn't include `https` so it cant be validated as a URL
    process.env.VERCEL ? zod__WEBPACK_IMPORTED_MODULE_0__.z.string() : zod__WEBPACK_IMPORTED_MODULE_0__.z.string().url()),
    DISCORD_CLIENT_ID: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    DISCORD_CLIENT_SECRET: zod__WEBPACK_IMPORTED_MODULE_0__.z.string()
});
/**
 * You can't destruct `process.env` as a regular object in the Next.js
 * middleware, so you have to do it manually here.
 * @type {{ [k in keyof z.input<typeof serverSchema>]: string | undefined }}
 */ const serverEnv = {
    DATABASE_URL: process.env.DATABASE_URL,
    NODE_ENV: "production",
    NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
    NEXTAUTH_URL: process.env.NEXTAUTH_URL,
    DISCORD_CLIENT_ID: process.env.DISCORD_CLIENT_ID,
    DISCORD_CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET
};
/**
 * Specify your client-side environment variables schema here.
 * This way you can ensure the app isn't built with invalid env vars.
 * To expose them to the client, prefix them with `NEXT_PUBLIC_`.
 */ const clientSchema = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
});
/**
 * You can't destruct `process.env` as a regular object, so you have to do
 * it manually here. This is because Next.js evaluates this at build time,
 * and only used environment variables are included in the build.
 * @type {{ [k in keyof z.input<typeof clientSchema>]: string | undefined }}
 */ const clientEnv = {
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5694:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ env)
/* harmony export */ });
/* harmony import */ var _schema_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5596);
/* harmony import */ var _client_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5830);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_schema_mjs__WEBPACK_IMPORTED_MODULE_0__, _client_mjs__WEBPACK_IMPORTED_MODULE_1__]);
([_schema_mjs__WEBPACK_IMPORTED_MODULE_0__, _client_mjs__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-check
/**
 * This file is included in `/next.config.mjs` which ensures the app isn't built with invalid env vars.
 * It has to be a `.mjs`-file to be imported there.
 */ 

const _serverEnv = _schema_mjs__WEBPACK_IMPORTED_MODULE_0__/* .serverSchema.safeParse */ .Rz.safeParse(_schema_mjs__WEBPACK_IMPORTED_MODULE_0__/* .serverEnv */ .Nb);
if (!_serverEnv.success) {
    console.error("❌ Invalid environment variables:\n", ...(0,_client_mjs__WEBPACK_IMPORTED_MODULE_1__/* .formatErrors */ .o)(_serverEnv.error.format()));
    throw new Error("Invalid environment variables");
}
for (let key of Object.keys(_serverEnv.data)){
    if (key.startsWith("NEXT_PUBLIC_")) {
        console.warn("❌ You are exposing a server-side env-variable:", key);
        throw new Error("You are exposing a server-side env-variable");
    }
}
const env = {
    ..._serverEnv.data,
    ..._client_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env */ .O
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;