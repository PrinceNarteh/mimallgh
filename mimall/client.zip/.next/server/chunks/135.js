"use strict";
exports.id = 135;
exports.ids = [135];
exports.modules = {

/***/ 1135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_TopDeals)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/layout/SectionHeader.tsx


const SectionHeader = ({ label  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between border-b-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                className: "sh-underline relative md:text-3xl",
                children: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                className: "cursor-pointer font-bold text-orange-500",
                children: "See more..."
            })
        ]
    });
};
/* harmony default export */ const layout_SectionHeader = (SectionHeader);

;// CONCATENATED MODULE: ./src/components/Section.tsx



const Section = ({ label , children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "mx-auto w-11/12 py-7",
        children: [
            label && /*#__PURE__*/ jsx_runtime_.jsx(layout_SectionHeader, {
                label: label
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "mt-5 flex flex-wrap justify-evenly",
                children: children
            })
        ]
    });
};
/* harmony default export */ const components_Section = (Section);

;// CONCATENATED MODULE: ./src/components/TopDeals.tsx





const TopDeals = ({ topDeals  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(components_Section, {
        label: "Top Deals",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full overflow-y-auto",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex gap-5 pb-3",
                children: topDeals.map((topDeal, idx)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/products/${idx}`,
                        className: "cursor-pointer ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "relative h-40 w-40 shrink-0 overflow-hidden rounded-lg shadow-md",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: topDeal.image,
                                fill: true,
                                alt: ""
                            })
                        })
                    }, idx))
            })
        })
    });
};
/* harmony default export */ const components_TopDeals = (TopDeals);


/***/ })

};
;