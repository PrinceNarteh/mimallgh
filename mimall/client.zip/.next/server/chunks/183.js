"use strict";
exports.id = 183;
exports.ids = [183];
exports.modules = {

/***/ 2183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CheckoutContainer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Container.tsx
var Container = __webpack_require__(4175);
;// CONCATENATED MODULE: ./src/components/OrderSummary.tsx

const OrderSummary = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mx-auto w-full max-w-4xl overflow-x-auto rounded-md border border-gray-400 p-5 shadow",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full space-y-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    className: "sh-underline relative md:text-3xl",
                    children: "Order Summary"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative overflow-x-auto",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                        className: "w-full text-left text-sm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                className: "bg-gray-50 text-xs uppercase text-gray-700",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            scope: "col",
                                            className: "px-6 py-3",
                                            children: "Product name"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            scope: "col",
                                            className: "px-6 py-3",
                                            children: "Seller"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            scope: "col",
                                            className: "px-6 py-3",
                                            children: "Qty"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            scope: "col",
                                            className: "px-6 py-3 text-center",
                                            children: "Unit Price (\xa2)"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                            scope: "col",
                                            className: "px-6 py-3",
                                            children: "Amt"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-b bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-4 font-medium text-gray-900",
                                                children: "Apple MacBook Pro 17"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "Silver"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$2999"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$2999"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-b bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-4 font-medium text-gray-900",
                                                children: "Microsoft Surface Pro"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "White"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "10"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$1999"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$1999"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-b bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-4 font-medium text-gray-900",
                                                children: "Magic Mouse 2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "Black"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "8"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$99"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$99"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-2 font-bold text-gray-900",
                                                children: "Sub-Total"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2",
                                                children: "$2299"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-2 font-bold text-gray-900",
                                                children: "Service Charge"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2",
                                                children: "$"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2",
                                                children: "$1"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-2 font-bold text-gray-900",
                                                children: "Delivery Charge"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-2",
                                                children: "$99"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                        className: "border-y-2 bg-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                scope: "row",
                                                className: "whitespace-nowrap px-6 py-4 font-bold text-gray-900",
                                                children: "Total"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                className: "px-6 py-4",
                                                children: "$99"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_OrderSummary = (OrderSummary);

;// CONCATENATED MODULE: ./src/components/CheckoutContainer.tsx




const CheckoutContainer = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Container/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mx-auto grid w-10/12 gap-10 pt-5 md:grid-cols-8",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-span-8 flex w-full bg-red-500 md:col-span-4",
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-span-8 md:col-span-4",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_OrderSummary, {})
                })
            ]
        })
    });
};
/* harmony default export */ const components_CheckoutContainer = (CheckoutContainer);


/***/ }),

/***/ 4175:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Container = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "pt-10",
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ })

};
;