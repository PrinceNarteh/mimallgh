"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 2104:
/***/ ((module) => {

module.exports = require("@next-auth/prisma-adapter");

/***/ }),

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 72:
/***/ ((module) => {

module.exports = require("superjson");

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = import("@trpc/server");;

/***/ }),

/***/ 6282:
/***/ ((module) => {

module.exports = import("@trpc/server/adapters/next");;

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 3628:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6282);
/* harmony import */ var _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5694);
/* harmony import */ var _server_api_trpc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9120);
/* harmony import */ var _server_api_root__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1149);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__, _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__, _server_api_trpc__WEBPACK_IMPORTED_MODULE_2__, _server_api_root__WEBPACK_IMPORTED_MODULE_3__]);
([_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__, _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__, _server_api_trpc__WEBPACK_IMPORTED_MODULE_2__, _server_api_root__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// export API handler
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__.createNextApiHandler)({
    router: _server_api_root__WEBPACK_IMPORTED_MODULE_3__/* .appRouter */ .q,
    createContext: _server_api_trpc__WEBPACK_IMPORTED_MODULE_2__/* .createTRPCContext */ .uw,
    onError: _env_server_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env.NODE_ENV */ .O.NODE_ENV === "development" ? ({ path , error  })=>{
        console.error(`❌ tRPC failed on ${path ?? "<no-path>"}: ${error.message}`);
    } : undefined
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ appRouter)
/* harmony export */ });
/* harmony import */ var _routers_products__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5360);
/* harmony import */ var _routers_shops__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4082);
/* harmony import */ var _routers_users__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9186);
/* harmony import */ var _trpc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9120);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_routers_products__WEBPACK_IMPORTED_MODULE_0__, _routers_shops__WEBPACK_IMPORTED_MODULE_1__, _routers_users__WEBPACK_IMPORTED_MODULE_2__, _trpc__WEBPACK_IMPORTED_MODULE_3__]);
([_routers_products__WEBPACK_IMPORTED_MODULE_0__, _routers_shops__WEBPACK_IMPORTED_MODULE_1__, _routers_users__WEBPACK_IMPORTED_MODULE_2__, _trpc__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




/**
 * This is the primary router for your server.
 *
 * All routers added in /api/routers should be manually added here
 */ const appRouter = (0,_trpc__WEBPACK_IMPORTED_MODULE_3__/* .createTRPCRouter */ .hA)({
    users: _routers_users__WEBPACK_IMPORTED_MODULE_2__/* .authRouter */ .m,
    products: _routers_products__WEBPACK_IMPORTED_MODULE_0__/* .productsRouter */ .D,
    shops: _routers_shops__WEBPACK_IMPORTED_MODULE_1__/* .shopRouter */ .X
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5360:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D": () => (/* binding */ productsRouter)
/* harmony export */ });
/* harmony import */ var _trpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9120);
/* harmony import */ var _utils_validations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7842);
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2937);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc__WEBPACK_IMPORTED_MODULE_0__, _utils_validations__WEBPACK_IMPORTED_MODULE_1__, _trpc_server__WEBPACK_IMPORTED_MODULE_2__]);
([_trpc__WEBPACK_IMPORTED_MODULE_0__, _utils_validations__WEBPACK_IMPORTED_MODULE_1__, _trpc_server__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const productsRouter = (0,_trpc__WEBPACK_IMPORTED_MODULE_0__/* .createTRPCRouter */ .hA)({
    getAllProducts: _trpc__WEBPACK_IMPORTED_MODULE_0__/* .publicProcedure.query */ .$y.query(async ({ ctx  })=>{
        const products = await ctx.prisma.product.findMany({
            include: {
                images: true,
                shop: {
                    select: {
                        name: true
                    }
                }
            }
        });
        return products;
    }),
    getProductById: _trpc__WEBPACK_IMPORTED_MODULE_0__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_1__/* .IdDto */ .BM).query(async ({ input , ctx  })=>{
        const product = await ctx.prisma.product.findUnique({
            where: {
                id: input.id
            },
            include: {
                shop: true
            }
        });
        return product;
    }),
    createProduct: _trpc__WEBPACK_IMPORTED_MODULE_0__/* .protectedProcedure.input */ .U5.input(_utils_validations__WEBPACK_IMPORTED_MODULE_1__/* .createProductDto */ .GL).mutation(async ()=>{
    // try {
    //   const product = ctx.prisma.product.create({
    //     data: {
    //       ...input,
    //       // shopId: ctx.session.user,
    //     },
    //   });
    // } catch (error) {}
    }),
    deleteProduct: _trpc__WEBPACK_IMPORTED_MODULE_0__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_1__/* .IdDto */ .BM).mutation(async ({ input , ctx  })=>{
        try {
            await ctx.prisma.product.delete({
                where: {
                    id: input.id
                }
            });
        } catch (error) {
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_2__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    })
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4082:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ shopRouter)
/* harmony export */ });
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2937);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9926);
/* harmony import */ var _utils_validations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7842);
/* harmony import */ var _trpc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9120);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_server__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__, _utils_validations__WEBPACK_IMPORTED_MODULE_2__, _trpc__WEBPACK_IMPORTED_MODULE_3__]);
([_trpc_server__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__, _utils_validations__WEBPACK_IMPORTED_MODULE_2__, _trpc__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const shopRouter = (0,_trpc__WEBPACK_IMPORTED_MODULE_3__/* .createTRPCRouter */ .hA)({
    getAllShops: _trpc__WEBPACK_IMPORTED_MODULE_3__/* .publicProcedure.query */ .$y.query(async ({ ctx  })=>{
        const shops = await ctx.prisma.shop.findMany({
            include: {
                owner: {
                    select: {
                        id: true,
                        firstName: true,
                        middleName: true,
                        lastName: true
                    }
                },
                branches: true
            }
        });
        return shops;
    }),
    getShopById: _trpc__WEBPACK_IMPORTED_MODULE_3__/* .publicProcedure.input */ .$y.input(zod__WEBPACK_IMPORTED_MODULE_1__.z.object({
        shopId: zod__WEBPACK_IMPORTED_MODULE_1__.z.string().cuid()
    })).query(async ({ input , ctx  })=>{
        const shop = await ctx.prisma.shop.findUnique({
            where: {
                id: input.shopId
            },
            include: {
                owner: {
                    select: {
                        firstName: true,
                        middleName: true,
                        lastName: true
                    }
                },
                branches: true
            }
        });
        return shop;
    }),
    createShop: _trpc__WEBPACK_IMPORTED_MODULE_3__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_2__/* .createShopDto */ .hG).mutation(async ({ input , ctx  })=>{
        try {
            const res = await ctx.prisma.shop.create({
                data: {
                    ...input,
                    branches: {
                        createMany: {
                            data: input.branches
                        }
                    }
                }
            });
            return res;
        } catch (error) {
            return new _trpc_server__WEBPACK_IMPORTED_MODULE_0__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    updateShop: _trpc__WEBPACK_IMPORTED_MODULE_3__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_2__/* .updateShopDto */ .OD).mutation(async ({ input , ctx  })=>{
        try {
            const shop = await ctx.prisma.shop.findUnique({
                where: {
                    id: input.id
                },
                include: {
                    branches: true
                }
            });
            if (!shop) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_0__.TRPCError({
                    code: "NOT_FOUND",
                    message: "Shop Not Found"
                });
            }
            const { branches , ...update } = input;
            const newBranches = branches.map((branch)=>({
                    location: branch.location,
                    address: branch.address,
                    phoneNumber: branch.phoneNumber
                }));
            const res = await ctx.prisma.shop.update({
                where: {
                    id: input.id
                },
                data: {
                    ...update,
                    branches: {
                        deleteMany: {
                            shopId: input.id
                        },
                        createMany: {
                            data: newBranches
                        }
                    }
                },
                include: {
                    branches: true
                }
            });
            return res;
        } catch (error) {
            return new _trpc_server__WEBPACK_IMPORTED_MODULE_0__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    deleteShop: _trpc__WEBPACK_IMPORTED_MODULE_3__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_2__/* .IdDto */ .BM).mutation(async ({ input , ctx  })=>{
        try {
            await ctx.prisma.shop.delete({
                where: {
                    id: input.id
                }
            });
        } catch (error) {
            return new _trpc_server__WEBPACK_IMPORTED_MODULE_0__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    })
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9186:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ authRouter)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2937);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9926);
/* harmony import */ var _utils_validations__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7842);
/* harmony import */ var _trpc__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9120);
/* harmony import */ var _utils_mapper__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5115);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_server__WEBPACK_IMPORTED_MODULE_1__, zod__WEBPACK_IMPORTED_MODULE_3__, _utils_validations__WEBPACK_IMPORTED_MODULE_4__, _trpc__WEBPACK_IMPORTED_MODULE_5__]);
([_trpc_server__WEBPACK_IMPORTED_MODULE_1__, zod__WEBPACK_IMPORTED_MODULE_3__, _utils_validations__WEBPACK_IMPORTED_MODULE_4__, _trpc__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const authRouter = (0,_trpc__WEBPACK_IMPORTED_MODULE_5__/* .createTRPCRouter */ .hA)({
    register: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .createUserDto */ .C0).mutation(async ({ input , ctx  })=>{
        try {
            const hashedPassword = await bcryptjs__WEBPACK_IMPORTED_MODULE_2___default().hash(input.password, 12);
            const user = await ctx.prisma.user.create({
                data: {
                    ...input,
                    password: hashedPassword
                }
            });
            return user;
        } catch (error) {
            if (error instanceof _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError && error.message.includes("User_phoneNumber")) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "CONFLICT",
                    message: "Phone number already in used"
                });
            }
            if (error instanceof _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError && error.message.includes("User_email")) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "CONFLICT",
                    message: "Email already in used"
                });
            }
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    updateUser: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .updateUserDto */ .d2).mutation(async ({ input , ctx  })=>{
        try {
            const user = await ctx.prisma.user.update({
                where: {
                    id: input?.id
                },
                data: {
                    ...input
                }
            });
            return user;
        } catch (error) {
            if (error instanceof _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError && error.message.includes("User_email_key")) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "CONFLICT",
                    message: "Email already in used."
                });
            }
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    deleteUser: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .IdDto */ .BM).mutation(async ({ input , ctx  })=>{
        try {
            await ctx.prisma.user.delete({
                where: {
                    id: input.id
                }
            });
        } catch (error) {
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    getUserById: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .IdDto */ .BM).query(async ({ input , ctx  })=>{
        const user = await ctx.prisma.user.findUnique({
            where: {
                id: input.id
            }
        });
        return user;
    }),
    getUsersByRole: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(zod__WEBPACK_IMPORTED_MODULE_3__.z.object({
        role: zod__WEBPACK_IMPORTED_MODULE_3__.z["enum"]([
            "admin",
            "user",
            "shop_owner"
        ], {
            required_error: "Role is required."
        })
    })).query(async ({ input , ctx  })=>{
        try {
            const users = await ctx.prisma.user.findMany({
                where: {
                    role: _utils_mapper__WEBPACK_IMPORTED_MODULE_6__/* .mapRoleStringToEnum */ .J3[input.role]
                }
            });
            return users;
        } catch (error) {}
    }),
    getAllShopOwners: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.query */ .$y.query(async ({ ctx  })=>{
        const shopOwners = await ctx.prisma.user.findMany({
            where: {
                role: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.SHOP_OWNER
            },
            include: {
                shop: {
                    select: {
                        name: true
                    }
                }
            }
        });
        return shopOwners;
    }),
    getShopOwnerBy: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(zod__WEBPACK_IMPORTED_MODULE_3__.z.object({
        id: zod__WEBPACK_IMPORTED_MODULE_3__.z.string({
            required_error: "ID is required"
        }).cuid()
    })).query(async ({ input , ctx  })=>{
        const shopOwners = await ctx.prisma.user.findUnique({
            where: {
                id: input.id
            },
            include: {
                shop: {
                    select: {
                        name: true
                    }
                }
            }
        });
        return shopOwners;
    }),
    createAdmin: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .createAdminDto */ .Gh).mutation(async ({ input , ctx  })=>{
        try {
            const hashedPassword = await bcryptjs__WEBPACK_IMPORTED_MODULE_2___default().hash(input.password, 12);
            const admin = await ctx.prisma.user.create({
                data: {
                    ...input,
                    password: hashedPassword,
                    role: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.ADMIN,
                    level: _utils_mapper__WEBPACK_IMPORTED_MODULE_6__/* .mapStringToLevel */ .j[input.level]
                }
            });
            return admin;
        } catch (error) {
            if (error instanceof _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError && error.message.includes("User_email_key")) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "CONFLICT",
                    message: "Email already in used."
                });
            }
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    }),
    updateAdmin: _trpc__WEBPACK_IMPORTED_MODULE_5__/* .publicProcedure.input */ .$y.input(_utils_validations__WEBPACK_IMPORTED_MODULE_4__/* .updateAdminDto */ .k_).mutation(async ({ input , ctx  })=>{
        try {
            let admin = await ctx.prisma.user.findUnique({
                where: {
                    id: input.id
                }
            });
            if (!admin) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "NOT_FOUND",
                    message: "User not found"
                });
            }
            admin = await ctx.prisma.user.update({
                where: {
                    id: input.id
                },
                data: {
                    ...input,
                    role: input.role,
                    level: _utils_mapper__WEBPACK_IMPORTED_MODULE_6__/* .mapStringToLevel */ .j[input.level]
                }
            });
            return admin;
        } catch (error) {
            if (error instanceof _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError && error.message.includes("User_email_key")) {
                throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                    code: "CONFLICT",
                    message: "Email already in used."
                });
            }
            throw new _trpc_server__WEBPACK_IMPORTED_MODULE_1__.TRPCError({
                code: "INTERNAL_SERVER_ERROR",
                message: "Something went wrong"
            });
        }
    })
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$y": () => (/* binding */ publicProcedure),
/* harmony export */   "U5": () => (/* binding */ protectedProcedure),
/* harmony export */   "hA": () => (/* binding */ createTRPCRouter),
/* harmony export */   "uw": () => (/* binding */ createTRPCContext)
/* harmony export */ });
/* unused harmony exports adminProtectedProcedure, adminOrShopOwnerProtectedProcedure */
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2476);
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7837);
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2937);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(superjson__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_auth__WEBPACK_IMPORTED_MODULE_0__, _db__WEBPACK_IMPORTED_MODULE_1__, _trpc_server__WEBPACK_IMPORTED_MODULE_2__]);
([_auth__WEBPACK_IMPORTED_MODULE_0__, _db__WEBPACK_IMPORTED_MODULE_1__, _trpc_server__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * YOU PROBABLY DON'T NEED TO EDIT THIS FILE, UNLESS:
 * 1. You want to modify request context (see Part 1)
 * 2. You want to create a new middleware or type of procedure (see Part 3)
 *
 * tl;dr - this is where all the tRPC server stuff is created and plugged in.
 * The pieces you will need to use are documented accordingly near the end
 */ /**
 * 1. CONTEXT
 *
 * This section defines the "contexts" that are available in the backend API
 *
 * These allow you to access things like the database, the session, etc, when
 * processing a request
 *
 */ 

/**
 * This helper generates the "internals" for a tRPC context. If you need to use
 * it, you can export it from here
 *
 * Examples of things you may need it for:
 * - testing, so we dont have to mock Next.js' req/res
 * - trpc's `createSSGHelpers` where we don't have req/res
 * @see https://create.t3.gg/en/usage/trpc#-servertrpccontextts
 */ const createInnerTRPCContext = (opts)=>{
    return {
        session: opts.session,
        prisma: _db__WEBPACK_IMPORTED_MODULE_1__/* .prisma */ ._
    };
};
/**
 * This is the actual context you'll use in your router. It will be used to
 * process every request that goes through your tRPC endpoint
 * @link https://trpc.io/docs/context
 */ const createTRPCContext = async (opts)=>{
    const { req , res  } = opts;
    // Get the session from the server using the unstable_getServerSession wrapper function
    const session = await (0,_auth__WEBPACK_IMPORTED_MODULE_0__/* .getServerAuthSession */ .W)({
        req,
        res
    });
    return createInnerTRPCContext({
        session
    });
};
/**
 * 2. INITIALIZATION
 *
 * This is where the trpc api is initialized, connecting the context and
 * transformer
 */ 


const t = _trpc_server__WEBPACK_IMPORTED_MODULE_2__.initTRPC.context().create({
    transformer: (superjson__WEBPACK_IMPORTED_MODULE_3___default()),
    errorFormatter ({ shape  }) {
        return shape;
    }
});
/**
 * 3. ROUTER & PROCEDURE (THE IMPORTANT BIT)
 *
 * These are the pieces you use to build your tRPC API. You should import these
 * a lot in the /src/server/api/routers folder
 */ /**
 * This is how you create new routers and subrouters in your tRPC API
 * @see https://trpc.io/docs/router
 */ const createTRPCRouter = t.router;
/**
 * Public (unauthed) procedure
 *
 * This is the base piece you use to build new queries and mutations on your
 * tRPC API. It does not guarantee that a user querying is authorized, but you
 * can still access user session data if they are logged in
 */ const publicProcedure = t.procedure;
/**
 * Reusable middleware that enforces users are logged in before running the
 * procedure
 */ const enforceUserIsAuthed = t.middleware(({ ctx , next  })=>{
    if (!ctx.session || !ctx.session.user) {
        throw new _trpc_server__WEBPACK_IMPORTED_MODULE_2__.TRPCError({
            code: "UNAUTHORIZED"
        });
    }
    return next({
        ctx: {
            // infers the `session` as non-nullable
            session: {
                ...ctx.session,
                user: ctx.session.user
            }
        }
    });
});
const enforceUserIsAdmin = t.middleware(({ ctx , next  })=>{
    if (!ctx.session || !ctx.session.user || ctx.session.user.role !== _prisma_client__WEBPACK_IMPORTED_MODULE_4__.Role.ADMIN) {
        throw new _trpc_server__WEBPACK_IMPORTED_MODULE_2__.TRPCError({
            code: "UNAUTHORIZED"
        });
    }
    return next({
        ctx: {
            // infers the `session` as non-nullable
            session: {
                ...ctx.session,
                user: ctx.session.user
            }
        }
    });
});
const enforceUserIsAdminOrShopOwner = t.middleware(({ ctx , next  })=>{
    if (!ctx.session || !ctx.session.user || ctx.session.user.role !== (_prisma_client__WEBPACK_IMPORTED_MODULE_4__.Role.ADMIN || _prisma_client__WEBPACK_IMPORTED_MODULE_4__.Role.SHOP_OWNER)) {
        throw new _trpc_server__WEBPACK_IMPORTED_MODULE_2__.TRPCError({
            code: "UNAUTHORIZED"
        });
    }
    return next({
        ctx: {
            // infers the `session` as non-nullable
            session: {
                ...ctx.session,
                user: ctx.session.user
            }
        }
    });
});
/**
 * Protected (authed) procedure
 *
 * If you want a query or mutation to ONLY be accessible to logged in users, use
 * this. It verifies the session is valid and guarantees ctx.session.user is not
 * null
 *
 * @see https://trpc.io/docs/procedures
 */ const protectedProcedure = t.procedure.use(enforceUserIsAuthed);
const adminProtectedProcedure = t.procedure.use(enforceUserIsAdmin);
const adminOrShopOwnerProtectedProcedure = t.procedure.use(enforceUserIsAdminOrShopOwner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J3": () => (/* binding */ mapRoleStringToEnum),
/* harmony export */   "j": () => (/* binding */ mapStringToLevel)
/* harmony export */ });
/* unused harmony exports mapRoleEnumToString, mapLevelToString, mapLevelToText, mapCategoryToString, mapStringToCategory */
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);

const mapRoleEnumToString = {
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.ADMIN]: "admin",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.USER]: "user",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.SHOP_OWNER]: "shop_owner"
};
const mapRoleStringToEnum = {
    admin: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.ADMIN,
    user: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.USER,
    shop_owner: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Role.SHOP_OWNER
};
const mapLevelToString = {
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_ONE]: "level_one",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_TWO]: "level_two",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_THREE]: "level_three",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.SUPER_USER]: "super_user"
};
const mapStringToLevel = {
    level_one: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_ONE,
    level_two: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_TWO,
    level_three: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.LEVEL_THREE,
    super_user: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Level.SUPER_USER
};
const mapLevelToText = (level)=>{
    return level?.split("_").map((l)=>`${String(l[0])} + ${l.substring(1).toLowerCase()}`).join(" ");
};
const mapCategoryToString = {
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.FOOD]: "food",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.FASHION_AND_WEARS]: "fashion_and_wears",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.GROCERY_AND_GENERAL]: "grocery_and_general",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.HEALTH_AND_WELLNESS]: "health_and_wellness",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.HOME_AND_ELECTRICAL_APPLIANCES]: "home_and_electrical_appliances",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.PERSONAL_SERVICES]: "personal_services",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.PRINTING_AND_STATIONERY]: "printing_and_stationery",
    [_prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.TECH]: "tech"
};
const mapStringToCategory = {
    food: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.FOOD,
    fashion_and_wears: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.FASHION_AND_WEARS,
    grocery_and_general: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.GROCERY_AND_GENERAL,
    health_and_wellness: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.HEALTH_AND_WELLNESS,
    home_and_electrical_appliances: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.HOME_AND_ELECTRICAL_APPLIANCES,
    personal_services: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.PERSONAL_SERVICES,
    printing_and_stationery: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.PRINTING_AND_STATIONERY,
    tech: _prisma_client__WEBPACK_IMPORTED_MODULE_0__.Category.TECH
};


/***/ }),

/***/ 7842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BM": () => (/* binding */ IdDto),
/* harmony export */   "C0": () => (/* binding */ createUserDto),
/* harmony export */   "GL": () => (/* binding */ createProductDto),
/* harmony export */   "Gh": () => (/* binding */ createAdminDto),
/* harmony export */   "OD": () => (/* binding */ updateShopDto),
/* harmony export */   "d2": () => (/* binding */ updateUserDto),
/* harmony export */   "hG": () => (/* binding */ createShopDto),
/* harmony export */   "k_": () => (/* binding */ updateAdminDto)
/* harmony export */ });
/* unused harmony exports updateProductDto, loginDto */
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([zod__WEBPACK_IMPORTED_MODULE_0__]);
zod__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const IdDto = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    id: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "ID is required"
    }).cuid()
});
const createProductDto = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    title: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    description: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Description is required"
    }).min(2, "Description should be 2 or more characters"),
    price: zod__WEBPACK_IMPORTED_MODULE_0__.z.number({
        required_error: "Price is required"
    }).gte(0, "Price cannot be negative"),
    discountPercentage: zod__WEBPACK_IMPORTED_MODULE_0__.z.number().gte(0, "Price cannot be negative").optional(),
    stock: zod__WEBPACK_IMPORTED_MODULE_0__.z.number({
        required_error: "Stock is required"
    }).gte(0, "Price cannot be negative"),
    brand: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Brand is required"
    }).min(2, "Brand should be 2 or more characters"),
    category: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "accommodations_and_building",
        "fashion_and_wears",
        "food",
        "furniture",
        "grocery_and_general",
        "health-and-wellness",
        "home_and_electricals",
        "money_and_energy",
        "personal-care_and_beauty",
        "recreation",
        "stationery_and_printing",
        "tech",
        "transport_and_machines"
    ]),
    ratings: zod__WEBPACK_IMPORTED_MODULE_0__.z.number().min(1, "Minimum rating should be 1").max(5, "Maximum rating should be 5").optional(),
    images: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().url().optional()
});
const updateProductDto = createProductDto.partial();
const createUserDto = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    firstName: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "First name is required."
    }).min(1, "First name cannot be empty"),
    lastName: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Last name is required."
    }).min(1, "Last name cannot be empty"),
    middleName: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    email: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Email name is required."
    }).email(),
    address: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    phoneNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Phone number is required."
    }).length(10, "Phone number must be ten numbers"),
    alternateNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    password: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Password name is required."
    }).min(6, "Password should be six character or more"),
    nationality: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().default(""),
    image: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Password name is required."
    }).optional(),
    role: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "ADMIN",
        "SHOP_OWNER",
        "USER"
    ], {
        required_error: "Role is required",
        invalid_type_error: "Invalid role value. Expect 'ADMIN' | 'SHOP_OWNER' | 'USER'"
    })
});
const updateUserDto = createUserDto.extend({
    id: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "ID is required."
    }).cuid()
});
// export const createShopOwnerDto = createUserDto
//   .extend({
//     confirmPassword: z
//       .string({ required_error: "Confirm password name is required." })
//       .min(6, "Password must be at least 6 characters"),
//   })
//   .optional()
//   .refine((val) => val?.password === val?.confirmPassword, {
//     message: "Passwords don't match",
//     path: ["confirmPassword"],
//   });
const createAdminDto = createUserDto.extend({
    cardType: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "ghana_card",
        "student_id",
        "voters_id"
    ]),
    cardNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Card number is required"
    }).min(1, "Card number cannot be empty"),
    level: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "level_one",
        "level_two",
        "level_three",
        "super_user"
    ]),
    role: zod__WEBPACK_IMPORTED_MODULE_0__.z["enum"]([
        "ADMIN",
        "SHOP_OWNER",
        "USER"
    ], {
        required_error: "Role is required",
        invalid_type_error: "Invalid role value. Expect 'ADMIN' | 'SHOP_OWNER' | 'USER'"
    })
});
const updateAdminDto = createAdminDto.extend({
    id: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "ID is required"
    }).cuid()
});
const loginDto = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    email: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Email is required"
    }).email(),
    password: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Password is required"
    }).max(6, "Password should be six character or more")
});
const createShopDto = zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
    ownerId: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Shop Owner Id is required"
    }).cuid("Enter valid ID"),
    name: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Shop name is required"
    }).min(1, "Shop name cannot be empty"),
    location: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Location is required"
    }).min(1, "Location cannot be empty"),
    address: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    phoneNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: "Phone number is required"
    }).length(10, "Phone number must be 10 characters"),
    description: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    openingTime: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    closingTime: zod__WEBPACK_IMPORTED_MODULE_0__.z.string(),
    facebookHandle: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    instagramHandle: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    whatsappNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string().optional(),
    branches: zod__WEBPACK_IMPORTED_MODULE_0__.z.array(zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
        location: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1),
        address: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1).optional(),
        phoneNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1)
    }))
});
const updateShopDto = createShopDto.extend({
    id: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
        required_error: ""
    }).cuid(),
    branches: zod__WEBPACK_IMPORTED_MODULE_0__.z.array(zod__WEBPACK_IMPORTED_MODULE_0__.z.object({
        id: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: ""
        }).cuid().optional(),
        shopId: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Shop Owner Id is required"
        }).cuid("Enter valid ID").optional(),
        location: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1),
        address: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1).optional(),
        phoneNumber: zod__WEBPACK_IMPORTED_MODULE_0__.z.string({
            required_error: "Location is required."
        }).min(1)
    }))
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [476], () => (__webpack_exec__(3628)));
module.exports = __webpack_exports__;

})();